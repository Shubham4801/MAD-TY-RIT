package shubham.example.activitydemo;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import static android.support.v7.app.AlertDialog.*;

public class MainActivity extends AppCompatActivity {

    private TextView mTextMessage;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_dashboard:
                    mTextMessage.setText(R.string.title_dashboard);
                    return true;
                case R.id.navigation_notifications:
                    mTextMessage.setText(R.string.title_notifications);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        Log.i("onCreate()", "created");
    };
    @Override
    protected void  onStart(){
        super.onStart();
        Log.i("onStart()", "started ");

    };
    protected void  onResume(){
        super.onResume();
        Log.i("onResume()", "resumed");

    };
    protected void  onPause(){
        super.onPause();
        Log.i("onPause()", "paused ");

    };

    protected void  onStop(){
        super.onStop();
        Log.i("onStop()", "stopped ");

    };
    protected void  onDestroy(){
        super.onDestroy();
        Log.i("onDestroy()", "Destroyed ");

    };

    public void next(View view)
    {
        Intent i=new Intent(this, Second_Activity.class);
        startActivity(i);
        AlertDialog.Builder ab=new AlertDialog.Builder(this);
        ab.setTitle("next activity");
        ab.setMessage("you started new activity");
        ab.setPositiveButton("Ok", new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, "Entered Ok", Toast.LENGTH_SHORT).show();
            }

        });
        ab.setNegativeButton("Cancel", new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, "Entered Cancel", Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog ad=ab.create();
        ad.show();

    };



}
