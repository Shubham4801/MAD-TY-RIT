    package com.example.phs.tenyearschallenge;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    EditText editText3;
    String role,username,password;
    Spinner spinner;
    public void getdata()
    {
        username = editText.getText().toString();
        password = editText3.getText().toString();
        role=spinner.getSelectedItem().toString();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText=findViewById(R.id.editText);
        editText3=findViewById(R.id.editText3);
        spinner=findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Values, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }
    public void login(View view)
    {
        getdata();
        if (username.equals("user") && password.equals("user") && role.equals("Faculty"))
        {
            Intent i=new Intent(this,Faculty.class);
            startActivity(i);
        }
        else if(username.equals("stud") && password.equals("stud") && role.equals("Student"))
            {
                Intent i=new Intent(this,student.class);
                startActivity(i);
            }
        else if(username.equals("lab") && password.equals("lab123") && role.equals("Lab assistant"))
        {
            Intent i=new Intent(this,Lab.class);
            startActivity(i);
        }
        else
        {
            Toast.makeText(this, "Enter Valid Credentials", Toast.LENGTH_SHORT).show();
        }
    }
    public void Reset(View view)
    {
        editText.setText(null);
        editText3.setText(null);
    }
}
