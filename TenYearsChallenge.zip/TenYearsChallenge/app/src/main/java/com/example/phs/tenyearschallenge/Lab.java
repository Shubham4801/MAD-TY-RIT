package com.example.phs.tenyearschallenge;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class Lab extends AppCompatActivity {
ImageView imageView3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab);
        imageView3=findViewById(R.id.imageView3);
    }
    public void TenYears(View view)
    {
        imageView3.setImageResource(R.drawable.john10);
        Toast.makeText(this, "Your Ten Years Challenge", Toast.LENGTH_SHORT).show();
    }
    public void Previous(View view)
    {
        Intent i=new Intent(this,MainActivity.class);
        startActivity(i);
    }
}
