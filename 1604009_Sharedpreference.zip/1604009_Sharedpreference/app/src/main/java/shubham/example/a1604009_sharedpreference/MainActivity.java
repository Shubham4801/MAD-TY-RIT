package shubham.example.a1604009_sharedpreference;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText ed1,ed2,ed3;
    SharedPreferences sp;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp = getPreferences(Context.MODE_PRIVATE);
        editor = sp.edit();
        ed1 = findViewById(R.id.editText);
        ed2 = findViewById(R.id.editText2);
        ed3 = findViewById(R.id.editText3);
        String s = sp.getString("Name", null);
        String s1 = sp.getString("Adhar", null);
        String s2 = sp.getString("PAN", null);
        ed1.setText(s);
        ed2.setText(s1);
        ed3.setText(s2);
    }
    public void save(View view)
    {
        editor.putString("name",ed1.getText().toString());
        editor.putString("mbno",ed2.getText().toString());
        editor.putString("city",ed3.getText().toString());
        editor.commit();
    }
    public void clear(View view)
    {
        ed1.setText("");
        ed2.setText("");
        ed3.setText("");
    }
    public void retrieve(View view)
    {
        String s=sp.getString("name",null);
        String s1=sp.getString("mbno",null);
        String s2=sp.getString("city",null);
        ed1.setText(s);
        ed2.setText(s1);
        ed3.setText(s2);
    }

}
